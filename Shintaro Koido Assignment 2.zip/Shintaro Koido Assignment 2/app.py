import os

from flask import Flask, request, render_template, make_response, redirect, url_for
from flask_sqlalchemy import SQLAlchemy 
from sqlalchemy import Integer, String, Float
from sqlalchemy.orm import Mapped, mapped_column 
from flask_wtf import FlaskForm
from wtforms import StringField, EmailField, TextAreaField, IntegerField, SubmitField
from wtforms.validators import DataRequired, Email, Length, NumberRange

app = Flask(__name__)

basedir = os.path.abspath(os.path.dirname(__file__))
app.config["SQLALCHEMY_DATABASE_URI"] = 'sqlite:///' + os.path.join(basedir, 'database.db')
app.config['SECRET_KEY'] ="General"
db = SQLAlchemy(app)

class CheckoutForm(FlaskForm):
    """Flask form allowing user input of personal information for order. 
    Used for processing checkout of order. Takes credit card details and validates
    """
    
    name = StringField('Name', validators=[DataRequired(), Length(min=1, max=50)])
    email = EmailField('Email', validators=[DataRequired(), Email()])
    address = TextAreaField('Address', validators=[DataRequired()])
    city = StringField('City', validators=[DataRequired(), Length(min=2, max=50)])
    state = StringField('State', validators=[DataRequired(), Length(min=2, max=4)])
    # will accept Australian postcodes only
    postcode = IntegerField('Postcode', validators=[DataRequired(), NumberRange(min=1000, max=8999)])
    credit_card = StringField('Credit Card Details', validators=[DataRequired(), Length(min=16, max=16)])
    expiry_month = IntegerField('Month of Expiry', validators=[DataRequired(), NumberRange(min=1, max=12)])
    expiry_year = IntegerField('Year of Expiry', validators=[DataRequired(), NumberRange(min=2023)])  # Adjust the minimum year as needed
    submit = SubmitField('Checkout')

class Orders(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)
    email = db.Column(db.String(100), nullable=False)
    address = db.Column(db.Text, nullable=False)
    city = db.Column(db.String(30), nullable=False)
    state = db.Column(db.String(3), nullable=False)
    postcode = db.Column(db.Integer, nullable=False)
    credit_card = db.Column(db.String(16), nullable=False)
    expiry_month = db.Column(db.Integer, nullable=False)
    expiry_year = db.Column(db.Integer, nullable=False)

class Products(db.Model):
    product_id: Mapped[Integer] = mapped_column(Integer, primary_key=True)
    product_name: Mapped[String] = mapped_column(String)
    product_description: Mapped[String] = mapped_column(String)
    price: Mapped[Float] = mapped_column(Float)

class Orders_Details(db.Model):
    id: Mapped[Integer] = mapped_column (Integer,primary_key=True)
    order_id: Mapped[Integer] = mapped_column(Integer)
    product_id: Mapped[Integer] = mapped_column(Integer)
    qty: Mapped[Integer] = mapped_column(Integer)
    
with app.app_context():
    db.create_all()
    

@app.route('/')
def index():
    return render_template('home.html') 

@app.route('/cart/add/<product_id>')
def addtocart(product_id):
    """Adds a product to the cart via the cart cookie

    Args:
        product_id (integer): product id from database 

    Returns:
        flask.Response: redirecting to product end-point
    """
    ids=[] # is populated from cart cookie 

    # Must check cart key is in cookie before accessing 
    if 'cart' in request.cookies:
        cart=request.cookies['cart']
        ids=cart.split(',')

    ids.append(product_id)

    #Custom response required to allow for setting cookie 
    response=make_response(redirect (url_for('products')))
    response.set_cookie('cart',','.join(ids))
    return response 

@app.route('/cart', methods= ['GET', 'POST'])
def cart():
    if not 'cart' in request.cookies:
        return render_template('Cart.html', products=[])
    if request.cookies['cart']=='':
        return render_template('Cart.html', products=[])
    cookies=request.cookies['cart'].split(',')
    if len(cookies) == 0:
        return render_template('Cart.html',products=[])
    #total price set initially at 0
    total =0
    products =[]
    #query price information from database
    for cookie in cookies:
        p=Products.query.filter_by(product_id=cookie).first()
        if p==None:
            continue
        products.append(p) 
        total=p.price+total 
    return render_template('Cart.html', products=products, total=total)
    #various app.routes for product pages
@app.route('/products')
def products():
    products = Products.query.all() 
    return render_template('productpage.html',products=products)

@app.route('/products/<product_id>')
def product(product_id):
    product = Products.query.filter_by(product_id=product_id).first()
    return render_template('product_1.html', people=product)
    


@app.route('/aboutus')
def aboutus():  
    return render_template('Aboutus.html')
    """Checkout draws from Cart and Add to Cart
    Has form based on db model and HTML
    Form validation bsed on wtf validators for each section
    Sends information to database then deletes cookies allowing for new session

    """

@app.route('/checkout', methods = ['GET','POST'])
def checkout():
    form = CheckoutForm()
    cart=request.cookies['cart'].split(',')
    if form.validate_on_submit():
         # Process the form data and save to the database
        order_details = Orders(
            name=form.name.data,
            email=form.email.data,
            address=form.address.data,
            city=form.city.data,
            state=form.state.data,
            postcode=form.postcode.data,
            credit_card=form.credit_card.data,
            expiry_month=form.expiry_month.data,
            expiry_year=form.expiry_year.data
        )
        db.session.add(order_details)
        db.session.commit()
        
        #commits data inputted to database about and below
        
        for product  in cart:
            
            item=Orders_Details(
            order_id=order_details.id,
            product_id=product, qty=1)
            db.session.add(item)
            db.session.commit()
        
        response=make_response (f'Your order is on its way: Order No. {order_details.id}')
        response.delete_cookie('cart')

        return response 
    total =0
    products =[]
    #calculation of price adding all product ID's appropriate prices to final
    for product in cart:
        p=Products.query.filter_by(product_id=product).first()
        if p==None:
            continue
        products.append(p) 
        total=p.price+total 
    return render_template('checkout.html',products=products, total=total, form=form)
    

if __name__ == '__main__':
    app.run(debug=True)
    