# Assignment 2 - Rapid Web Development 

Create a dynamic webpage using html, jinja2 with Python Flask, FlaskSQLAlchemy and WTForms. Database is SQLite

## Execute app 

These instructions show how to run the app locally on your machine. 


Requirements:
- Python3
- Python venv 
- SQLite 

### Windows 
```
python3 -m venv venv 
./venv/Scripts/Activate.ps1 
pip install -r requirements.txt
flask --app app.py run 
```
### Linux/MacOS 
```
python3 -m venv venv 
./venv/bin/activate 
pip install -r requirements.txt
flask --app app.py run 
```